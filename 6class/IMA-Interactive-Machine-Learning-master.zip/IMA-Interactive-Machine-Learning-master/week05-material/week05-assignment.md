# Week 05: Backward Propagation
## [Some notes on optimizer](optimizers.md)
## [Avaiable loss built in keras](losses.md)
