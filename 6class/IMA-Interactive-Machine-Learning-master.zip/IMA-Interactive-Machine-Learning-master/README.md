# Interactive Machine Learning, Spring 2019
Interactive Machine Learning Class at Interactive Media Arts, NYU Shanghai. Spring 2019.

* Class Website: https://wp.nyu.edu/shanghai-ima-interactivemachinelearning/
* Instructors: [AVEN LE ZHOU](https://www.aven.cc) & [JH MOON](http://moqn.net), Supported by [Young Chung](https://github.com/yhchung)
