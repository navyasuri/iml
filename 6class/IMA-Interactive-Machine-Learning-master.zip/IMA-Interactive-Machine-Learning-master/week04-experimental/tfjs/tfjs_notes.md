* install tfjs 
    * pip install tensorflowjs *will not work :(*
    * conda install tensorflow=1.12.0
    * pip install h5py numpy keras
    * pip install --no-deps tensorflowjs

* or install with the yml file --> week04-prep --> environment.yml