Breeds classification demo

1. Unzip Classification demo using TF on breeds dataset on DevCloud.zip
2. Upload whole tf folder to DevCloud under HOME user path (E.g. /home/u14217/)
3. run cd tf
4. run sh prepare_env_tf
5. run sh qsub_tf


That's all!